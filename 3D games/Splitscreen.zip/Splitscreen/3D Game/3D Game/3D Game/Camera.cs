using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace _3D_Game
{
    public class Camera : Microsoft.Xna.Framework.GameComponent
    {
        //Camera matrices
        public Matrix view { get; protected set; }
        public Matrix projection { get; protected set; }
        public Viewport viewport { get; set; }

        // Vectors for the view matrix
        Vector3 cameraPosition;
        Vector3 cameraDirection;
        Vector3 cameraUp;
        Color c;
        // Speed
        float speed = 3;

        public Camera(Game game, Vector3 pos, Vector3 target,
            Vector3 up, Viewport viewport, Color c)
            : base(game)
        {
            // Create view matrix
            cameraPosition = pos;
            cameraDirection = target - pos;
            cameraDirection.Normalize();
            cameraUp = up;
            this.c = c;

            CreateLookAt();

            projection = Matrix.CreatePerspectiveFieldOfView(
                MathHelper.PiOver4,
                (float)viewport.Width /
                (float)viewport.Height,
                1, 3000);

            this.viewport = viewport;
        }

        public override void Initialize()
        {
            // TODO: Add your initialization code here

            base.Initialize();
        }

        public override void Update(GameTime gameTime)
        {

            CreateLookAt();
            

            base.Update(gameTime);
        }

        public void AddBoundingFrustum(Color c)
        {
            DebugShapeRenderer.AddBoundingFrustum(new BoundingFrustum(view * projection), c);
        }

        private void CreateLookAt()
        {
            view = Matrix.CreateLookAt(cameraPosition,
                cameraPosition + cameraDirection, cameraUp);
        }

        public void MoveForwardBackward(bool forward)
        {
            // Move forward/backward
            if (forward)
                cameraPosition += cameraDirection * speed;
            else
                cameraPosition -= cameraDirection * speed;
        }

        public void MoveStrafeLeftRight(bool left)
        {

            // Strafe
            if (left)
            {
                cameraPosition +=
                   Vector3.Cross(cameraUp, cameraDirection) * speed;
            }
            else
            {
                cameraPosition -=
                    Vector3.Cross(cameraUp, cameraDirection) * speed;
            }
        }
    }
}